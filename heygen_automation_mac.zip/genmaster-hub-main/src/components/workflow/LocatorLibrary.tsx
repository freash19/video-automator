import { useState } from "react";
import { MousePointer, Edit2, Trash2, Plus, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface Locator {
  id: string;
  name: string;
  selector: string;
  type: "css" | "xpath" | "id";
  description?: string;
}

const sampleLocators: Locator[] = [
  { id: "1", name: "Upload Button", selector: "#upload-btn", type: "id", description: "Main upload button" },
  { id: "2", name: "Script Input", selector: "textarea.script-area", type: "css", description: "Script text area" },
  { id: "3", name: "Generate Button", selector: "//button[contains(text(),'Generate')]", type: "xpath", description: "Trigger generation" },
  { id: "4", name: "Avatar Dropdown", selector: ".avatar-select", type: "css", description: "Avatar selection dropdown" },
  { id: "5", name: "Download Link", selector: "a.download-video", type: "css", description: "Download completed video" },
];

interface LocatorLibraryProps {
  onSelectLocator?: (locator: Locator) => void;
}

export function LocatorLibrary({ onSelectLocator }: LocatorLibraryProps) {
  const [locators, setLocators] = useState<Locator[]>(sampleLocators);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const filteredLocators = locators.filter(
    (loc) =>
      loc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      loc.selector.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleDelete = (id: string) => {
    setLocators(locators.filter((loc) => loc.id !== id));
  };

  const typeColors = {
    css: "bg-primary/20 text-primary",
    xpath: "bg-warning/20 text-warning",
    id: "bg-success/20 text-success",
  };

  return (
    <div className="rounded-xl border border-border shadow-card h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <MousePointer className="w-5 h-5 text-primary" />
            Locator Library
          </h3>
          <Button size="sm">
            <Plus className="w-4 h-4 mr-1" />
            Add New
          </Button>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search locators..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      {/* Locator List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2 scrollbar-thin">
        {filteredLocators.map((locator) => (
          <div
            key={locator.id}
            onClick={() => {
              setSelectedId(locator.id);
              onSelectLocator?.(locator);
            }}
            className={cn(
              "p-3 rounded-lg border cursor-pointer transition-all duration-200",
              selectedId === locator.id
                ? "border-primary bg-primary/5"
                : "border-border hover:border-muted-foreground/50 hover:bg-muted/30"
            )}
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="font-medium text-foreground">{locator.name}</span>
                <Badge className={cn("text-[10px] px-1.5", typeColors[locator.type])}>
                  {locator.type.toUpperCase()}
                </Badge>
              </div>
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" className="h-7 w-7">
                  <Edit2 className="w-3 h-3" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 text-destructive hover:text-destructive"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDelete(locator.id);
                  }}
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </div>
            <code className="text-xs text-muted-foreground font-mono block truncate">
              {locator.selector}
            </code>
            {locator.description && (
              <p className="text-xs text-muted-foreground/70 mt-1">{locator.description}</p>
            )}
          </div>
        ))}
      </div>

      {/* Footer */}
      <div className="p-3 border-t border-border bg-muted/20">
        <p className="text-xs text-muted-foreground text-center">
          {filteredLocators.length} locators available
        </p>
      </div>
    </div>
  );
}
