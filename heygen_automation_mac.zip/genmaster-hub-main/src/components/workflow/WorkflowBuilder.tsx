import { useEffect, useState } from "react";
import {
  MousePointerClick,
  Type,
  Navigation,
  Clock,
  Download,
  GripVertical,
  Plus,
  Trash2,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface WorkflowStep {
  id: string;
  type: string;
  params: Record<string, string>;
  enabled?: boolean;
}

const stepIcons = {
  click: MousePointerClick,
  type: Type,
  navigate: Navigation,
  wait: Clock,
  download: Download,
};

const stepColors = {
  click: "text-primary bg-primary/10",
  type: "text-success bg-success/10",
  navigate: "text-warning bg-warning/10",
  wait: "text-muted-foreground bg-muted",
  download: "text-purple-400 bg-purple-400/10",
};

interface Props {
  steps: WorkflowStep[];
  onStepsChange: (steps: WorkflowStep[]) => void;
  onSave?: () => void;
}

export function WorkflowBuilder({ steps, onStepsChange, onSave }: Props) {
  const [localSteps, setLocalSteps] = useState<WorkflowStep[]>(steps);
  useEffect(() => {
    setLocalSteps(steps);
  }, [JSON.stringify(steps)]);

  const moveStep = (index: number, direction: "up" | "down") => {
    const newSteps = [...localSteps];
    const newIndex = direction === "up" ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= localSteps.length) return;
    [newSteps[index], newSteps[newIndex]] = [newSteps[newIndex], newSteps[index]];
    setLocalSteps(newSteps);
    onStepsChange(newSteps);
  };

  const toggleStep = (id: string) => {
    const s = localSteps.map((step) => (step.id === id ? { ...step, enabled: !step.enabled } : step));
    setLocalSteps(s);
    onStepsChange(s);
  };

  const deleteStep = (id: string) => {
    const s = localSteps.filter((step) => step.id !== id);
    setLocalSteps(s);
    onStepsChange(s);
  };

  const addStep = () => {
    const newStep: WorkflowStep = {
      id: crypto.randomUUID(),
      type: "click",
      params: {},
      enabled: true,
    };
    const s = [...localSteps, newStep];
    setLocalSteps(s);
    onStepsChange(s);
  };

  return (
    <div className="rounded-xl border border-border shadow-card h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-foreground">Workflow Builder</h3>
          <div className="flex items-center gap-2">
          <Button size="sm" onClick={addStep}>
            <Plus className="w-4 h-4 mr-1" />
            Add Step
          </Button>
          {onSave && (
            <Button size="sm" variant="secondary" onClick={onSave}>
              Save
            </Button>
          )}
          </div>
        </div>
        <p className="text-sm text-muted-foreground mt-1">
          Define the automation steps in order
        </p>
      </div>

      {/* Steps List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2 scrollbar-thin">
        {localSteps.map((step, index) => {
          const Icon = stepIcons[(step.type as keyof typeof stepIcons) || "click"] || MousePointerClick;
          return (
            <div
              key={step.id}
              className={cn(
                "group p-4 rounded-lg border transition-all duration-200",
                step.enabled
                  ? "border-border bg-card hover:border-muted-foreground/50"
                  : "border-border/50 bg-muted/30 opacity-60"
              )}
            >
              <div className="flex items-center gap-3">
                {/* Drag Handle */}
                <div className="cursor-grab text-muted-foreground hover:text-foreground">
                  <GripVertical className="w-4 h-4" />
                </div>

                {/* Step Number */}
                <div className="w-6 h-6 rounded-full bg-muted flex items-center justify-center text-xs font-mono text-muted-foreground">
                  {index + 1}
                </div>

                {/* Icon */}
                <div className={cn("p-2 rounded-lg", stepColors[step.type])}>
                  <Icon className="w-4 h-4" />
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-foreground">{step.type}</span>
                    <Badge variant="secondary" className="text-[10px]">
                      {step.id}
                    </Badge>
                  </div>
                  <div className="text-xs text-muted-foreground truncate mt-0.5">
                    {Object.entries(step.params).map(([k, v]) => `${k}: ${v}`).join(" • ")}
                  </div>
                  <div className="mt-2 grid grid-cols-3 gap-2">
                    <input
                      className="px-2 py-1 rounded bg-muted/30 text-sm"
                      value={step.type}
                      onChange={(e) => {
                        const s = [...localSteps];
                        s[index] = { ...s[index], type: e.target.value };
                        setLocalSteps(s);
                        onStepsChange(s);
                      }}
                    />
                    <textarea
                      className="col-span-2 px-2 py-1 rounded bg-muted/30 text-xs font-mono"
                      rows={2}
                      value={JSON.stringify(step.params)}
                      onChange={(e) => {
                        try {
                          const obj = JSON.parse(e.target.value || "{}");
                          const s = [...localSteps];
                          s[index] = { ...s[index], params: obj };
                          setLocalSteps(s);
                          onStepsChange(s);
                        } catch {
                          // ignore invalid json
                        }
                      }}
                    />
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7"
                    onClick={() => moveStep(index, "up")}
                    disabled={index === 0}
                  >
                    <ChevronUp className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7"
                    onClick={() => moveStep(index, "down")}
                    disabled={index === steps.length - 1}
                  >
                    <ChevronDown className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className={cn("h-7 w-7", !step.enabled && "text-success")}
                    onClick={() => toggleStep(step.id)}
                  >
                    {step.enabled ? (
                      <span className="text-[10px] font-medium">ON</span>
                    ) : (
                      <span className="text-[10px] font-medium">OFF</span>
                    )}
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-destructive hover:text-destructive"
                    onClick={() => deleteStep(step.id)}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer */}
      <div className="p-3 border-t border-border bg-muted/20">
        <p className="text-xs text-muted-foreground text-center">
          {steps.filter((s) => s.enabled).length} of {steps.length} steps enabled
        </p>
      </div>
    </div>
  );
}
