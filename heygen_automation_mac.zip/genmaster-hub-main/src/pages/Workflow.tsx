import { useEffect, useState } from "react";
import { LocatorLibrary } from "@/components/workflow/LocatorLibrary";
import { WorkflowBuilder } from "@/components/workflow/WorkflowBuilder";
import { WizardNavigation } from "@/components/common/WizardNavigation";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { API_BASE_URL } from "@/lib/utils";

type WorkflowStep = {
  id: string;
  type: string;
  params: Record<string, string>;
  enabled?: boolean;
};

type WorkflowSettings = Record<string, unknown>;

export default function Workflow() {
  const API = API_BASE_URL;
  const [files, setFiles] = useState<string[]>([]);
  const [selected, setSelected] = useState<string>("");
  const [newWfFile, setNewWfFile] = useState<string>("");
  const [wfName, setWfName] = useState<string>("");
  const [steps, setSteps] = useState<WorkflowStep[]>([]);
  const [settings, setSettings] = useState<WorkflowSettings>({});

  useEffect(() => {
    const loadFiles = async () => {
      try {
        const res = await fetch(`${API}/workflows`).then((r) => r.json());
        setFiles(res.files || []);
      } catch {
        setFiles([]);
      }
    };
    loadFiles();
  }, [API]);

  useEffect(() => {
    const loadOne = async () => {
      if (!selected) return;
      try {
        const wf: { name?: string; steps?: WorkflowStep[]; settings?: WorkflowSettings } = await fetch(`${API}/workflows/${selected}`).then((r) => r.json());
        setWfName(wf.name || selected.replace(".json", ""));
        setSteps((wf.steps || []).map((s) => ({ id: s.id, type: s.type, params: s.params || {}, enabled: s.enabled })));
        setSettings(wf.settings || {});
      } catch {
        setSteps([]);
      }
    };
    loadOne();
  }, [API, selected]);

  const handleSave = async () => {
    const payload = { name: wfName || selected, steps, settings };
    await fetch(`${API}/workflows/${selected}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  };
  return (
    <div className="space-y-6 h-full">
      {/* Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-3">
          <h1 className="text-3xl font-bold tracking-tight text-foreground">
            Воркфлоу и локаторы
          </h1>
          <Badge variant="secondary" className="text-xs">Step 2</Badge>
        </div>
        <p className="text-muted-foreground">
          Выберите UI‑элементы и создайте сценарий автоматизации.
        </p>
      </div>

      {/* Workflow selector */}
      <div className="rounded-xl border border-border p-4 shadow-card">
        <div className="flex flex-col gap-3">
          <div className="flex items-center gap-3">
          <Select value={selected} onValueChange={setSelected}>
            <SelectTrigger className="w-[280px]">
              <SelectValue placeholder="Выберите файл воркфлоу" />
            </SelectTrigger>
            <SelectContent>
              {files.map((f) => (
                <SelectItem key={f} value={f}>
                  {f}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="secondary" onClick={handleSave} disabled={!selected}>
            Сохранить воркфлоу
          </Button>
          <Button
            onClick={async () => {
              if (!selected) return;
              const body = new URLSearchParams();
              body.append("workflow", selected);
              await fetch(`${API}/run`, { method: "POST", body });
            }}
            disabled={!selected}
          >
            Тестировать
          </Button>
          </div>
          <div className="flex items-center gap-2">
            <Input
              value={newWfFile}
              onChange={(e) => setNewWfFile(e.target.value)}
              placeholder="Новый воркфлоу (например my_flow.json)"
              className="max-w-[320px]"
            />
            <Button
              variant="outline"
              onClick={async () => {
                const raw = newWfFile.trim();
                if (!raw) return;
                const file = raw.toLowerCase().endsWith(".json") ? raw : `${raw}.json`;
                const payload = { name: raw.replace(/\.json$/i, ""), steps: [], settings: {} };
                await fetch(`${API}/workflows/${encodeURIComponent(file)}`, {
                  method: "PUT",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify(payload),
                });
                const res = await fetch(`${API}/workflows`).then((r) => r.json());
                setFiles(res.files || []);
                setSelected(file);
                setNewWfFile("");
              }}
            >
              Создать воркфлоу
            </Button>
          </div>
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          Выберите сохранённый воркфлоу, редактируйте шаги и параметры, затем сохраните. Каждый шаг можно включать/выключать, менять порядок, параметры принимают JSON.
        </p>
        <div className="mt-2 text-xs text-muted-foreground">
          Инструкция: добавьте новый элемент через библиотеку локаторов, затем используйте его селектор в шаге (params.selector). Таймаут шага укажите как params.delay_sec. Проверки шага — params.check, например {"{ \"exists\": true }"}.
        </div>
      </div>

      {/* Split View */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 min-h-[600px]">
        <div className="lg:col-span-2">
          <LocatorLibrary />
        </div>
        <div className="lg:col-span-3">
          <WorkflowBuilder steps={steps} onStepsChange={setSteps} onSave={handleSave} />
        </div>
      </div>

      {/* Wizard Navigation */}
      <WizardNavigation
        backPath="/data-studio"
        backLabel="Студия данных"
        nextPath="/settings"
        nextLabel="Настроить конфигурацию"
      />
    </div>
  );
}
